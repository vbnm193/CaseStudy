﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaseStudyTeam9.Models
{
    public interface ICustomerRepo
    {
        public int AddCustomer(Customer customer);
        public List<Customer> getAll(int page);
        bool DeleteCustomer(int customerID);
        public int UpdateCustomer(Customer customer);
        public Customer GetCustomerByID(int customerID);
        Customer SearchCustomer(string searchBy, int id);
        public List<Customer> GetAllCustomer(int skipCustomers);
    }
}
