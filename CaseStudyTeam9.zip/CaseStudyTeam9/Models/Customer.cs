﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CaseStudyTeam9.Models
{
    public class Customer
    {
        [Display(Name="Customer ID")]
        public int CustomerID { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        [Range(100000000, 999999999)]
        public int SSN { get; set; }
        [Required, Range(16, 100)]
        public int Age { get; set; }
        [Required, Display(Name="Address")]
        public string Address1 { get; set; }
        [Display(Name="Address 2 (optional)")]
        public string Address2 { get; set; }
        [Required]
        public string City { get; set; }
        [Required]
        public string State { get; set; }
        public string Status { get; set; }
        public string Message { get; set; }
        [Display(Name = "Last Updated")]
        public DateTime LastUpdated { get; set; } = System.DateTime.Now;
    }
}
