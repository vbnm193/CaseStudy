﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace CaseStudyTeam9.Models.ViewModel
{
    public class AccountCreateViewModel
    {
        public AccountViewModel AccountViewModelC { get; set; }
        public AccountViewModel AccountViewModelA { get; set; }
        public List<AccountViewModel> AccountViewModels { get; set; }
        public int id { get; set; }
        public string search { get; set; }
        public int acctID { get; set; }
    }
}
