﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace CaseStudyTeam9.Models
{
    public class TransactionsViewModel
    {
        [Key]
        public int TransactionID { get; set; }
        public int ToAccountID { get; set; }
        public int AccountID { get; set; }
        public int CustomerID { get; set; }
        public string AccountType { get; set; }

        [Range(1, Int32.MaxValue)]
        [Display(Name = "Transaction Amount")]
        public decimal TransactionAmount { get; set; }
        public decimal CurrentBalance { get; set; }
        public decimal ClosingBalance { get; set; }
        public DateTime TransactionDate { get; set; }
        public string Name { get; set; }

    }
}
