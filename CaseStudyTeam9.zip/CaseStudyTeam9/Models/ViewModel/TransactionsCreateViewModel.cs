﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace CaseStudyTeam9.Models.ViewModel
{
    public class TransactionsCreateViewModel
    {
        public List<TransactionsViewModel> transactionsViewModels { get; set; }
        public int RowNum { get; set; }
        public int acctID { get; set; }
    }
}
