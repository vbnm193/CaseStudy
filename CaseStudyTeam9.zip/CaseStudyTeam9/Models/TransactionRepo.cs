﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CaseStudyTeam9.Models.ViewModel;
using Microsoft.EntityFrameworkCore;

namespace CaseStudyTeam9.Models
{
    public class TransactionRepo : ITransactionRepo
    {
        TransactionContext _context;
        AccountContext _actContext;
        public TransactionRepo(TransactionContext context, AccountContext accountContext)
        {
            _context = context;
            _actContext = accountContext;
        }
        public Transactions DepositMoney(int AccountID, decimal transactionAmount)
        {
            Transactions tran = new Transactions();
            try
            {
                Account act = new Account();
                act = _actContext.Account.FirstOrDefault(a => a.AccountID == AccountID);
                if (act != null)
                {
                    act.Balance += transactionAmount;
                    tran.AccountID = AccountID;
                    tran.TransactionAmount = transactionAmount;
                    tran.CustomerID = act.CustomerID;
                    tran.CurrentBalance = act.Balance;
                    tran.AccountType = act.AccountType;
                    tran.ClosingBalance = act.Balance + transactionAmount;
                    tran.TransactionDate = System.DateTime.Now;
                    tran.ToAccountID = AccountID;
                    _context.Transactions.Add(tran);
                    _context.SaveChanges();
                    _actContext.Entry(act).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
                    _actContext.SaveChanges();
                    return tran;
                }
                else return null;
            }
            catch(Exception e){ Console.WriteLine(e.Message); return  null; }
        }
        public Transactions WithdrawMoney(int AccountID, decimal transactionAmount)
        {
            Transactions tran = new Transactions();
            try
            {
                Account act = new Account();
                var dAct = _actContext.Account.FirstOrDefault(a => a.AccountID == AccountID);
                act = dAct;
                if (act != null)
                {
                    if (transactionAmount > act.Balance) {
                        tran.TransactionAmount = -1;
                        return tran;
                    }                    
                    act.Balance -= transactionAmount;
                    tran.AccountID = AccountID;
                    tran.TransactionAmount = transactionAmount;
                    tran.CustomerID = act.CustomerID;
                    tran.CurrentBalance = act.Balance;
                    tran.AccountType = act.AccountType;
                    tran.ClosingBalance = act.Balance - transactionAmount;
                    tran.TransactionDate = System.DateTime.Now;
                    tran.ToAccountID = AccountID;
                    _context.Transactions.Add(tran);
                    _context.SaveChanges();
                    _actContext.Entry(act).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
                    _actContext.SaveChanges();
                    return tran;
                }
                return null;
            }
            catch
            {
                return null;
            }
        }
        public Transactions TransferMoney(int AccountID, int ToAccountID, decimal transactionAmount)
        {
            Transactions FromTran = new Transactions();
            Transactions ToTran = new Transactions();

            try
            {
                Account FromAct = new Account();
                Account ToAct = new Account();
                FromAct = _actContext.Account.FirstOrDefault(a => a.AccountID == AccountID);
                ToAct = _actContext.Account.FirstOrDefault(a => a.AccountID == ToAccountID);
                if (FromAct != null)
                {
                    if (transactionAmount > FromAct.Balance)
                    {
                        FromTran.TransactionAmount = -1;
                        return FromTran;
                    }
                    FromAct.Balance -= transactionAmount;
                    FromTran.AccountID = AccountID;
                    FromTran.TransactionAmount = transactionAmount;
                    FromTran.CustomerID = FromAct.CustomerID;
                    FromTran.CurrentBalance = FromAct.Balance;
                    FromTran.AccountType = FromAct.AccountType;
                    FromTran.ClosingBalance = FromAct.Balance - transactionAmount;
                    FromTran.TransactionDate = System.DateTime.Now;
                    FromTran.ToAccountID = ToAct.AccountID;
                    _context.Transactions.Add(FromTran);
                    _context.SaveChanges();
                    _actContext.Entry(FromAct).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
                    _actContext.SaveChanges();

                    if (ToAct != null)
                    {
                        ToAct.Balance += transactionAmount;
                        ToTran.AccountID = ToAccountID;
                        ToTran.TransactionAmount = transactionAmount;
                        ToTran.CustomerID = ToAct.CustomerID;
                        ToTran.CurrentBalance = ToAct.Balance;
                        ToTran.AccountType = ToAct.AccountType;
                        ToTran.ClosingBalance = ToAct.Balance + transactionAmount;
                        ToTran.TransactionDate = System.DateTime.Now;
                        ToTran.ToAccountID = ToAct.AccountID;
                        _context.Transactions.Add(ToTran);
                        _context.SaveChanges();
                        _actContext.Entry(ToAct).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
                        _actContext.SaveChanges();
                    }
                    return FromTran;
                }
                return null;
            }
            catch { return null; }           
        }
        public List<TransactionsViewModel> TranReport(int acctID, int RowNum)
        {
            var res = _context.Transactions
                .Where(a => a.AccountID == acctID)
                .Join(
                _context.Customer,
                t => t.CustomerID,
                a => a.CustomerID,
                (t, ta) => new TransactionsViewModel
                {
                    TransactionID = t.TransactionID,
                    AccountID = t.AccountID,
                    CustomerID = t.CustomerID,
                    Name = ta.Name,
                    AccountType = t.AccountType,
                    TransactionAmount = t.TransactionAmount,
                    CurrentBalance = t.CurrentBalance,
                    ClosingBalance = t.ClosingBalance,
                    TransactionDate = t.TransactionDate,
                    ToAccountID = t.ToAccountID
                }).Take(RowNum);
            return res.ToList();
        }
    }
}
