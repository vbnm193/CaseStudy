﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaseStudyTeam9.Models
{
    public class CustomerRepo : ICustomerRepo
    {
        public CustomerContext _context;
        public CustomerRepo(CustomerContext context)
        {
            _context = context;
        }
        public int AddCustomer(Customer customer)
        {
            customer.Status = "Created";
            customer.Message = "";
            customer.LastUpdated = DateTime.Now;
            _context.Customer.Add(customer);
            return _context.SaveChanges();
        }
        public List<Customer> getAll(int page)
        {
            int customerPerPage = 5;
            return _context.Customer.Skip(page * customerPerPage).Take(customerPerPage).ToList();
                      
        }
        public Customer GetCustomerByID(int customerID)
        {
            return _context.Customer.FirstOrDefault(c => c.CustomerID == customerID);
        }
        public int UpdateCustomer(Customer customer)
        {
            customer.Status = "Updated";
            customer.LastUpdated = System.DateTime.Now;
            _context.Entry(customer).State = EntityState.Modified;
            return _context.SaveChanges();
        }
        public List<Customer> GetAllCustomer(int skipCustomers)
        {
            int customerPerPage = 5;
            return _context.Customer.Skip(skipCustomers * customerPerPage).Take(customerPerPage).ToList();
        }
        public bool DeleteCustomer(int customerID)
        {
           
            var account = from areremove in _context.Account
                                where areremove.CustomerID == customerID
                                select areremove;


            if (account.Count() > 0)
            {
                return false;
            }

            var customer = from areremove in _context.Customer
                                 where areremove.CustomerID == customerID
                                 select areremove;

            foreach (var detail in customer)
            {
                _context.Customer.Remove(detail);

            }
            _context.SaveChanges();
            return true;
        }

        public Customer SearchCustomer(string searchBy, int id)

        {
            if (searchBy == "SSN")
            {
                return _context.Customer.FirstOrDefault(c => c.SSN == id);
            }
            else if (searchBy == "Customer ID")
            {
                return _context.Customer.FirstOrDefault(c => c.CustomerID == id);
            }
            else
            {
                return null;
            }
        }
    }
}
