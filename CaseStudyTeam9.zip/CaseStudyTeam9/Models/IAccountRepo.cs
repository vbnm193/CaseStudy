﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using CaseStudyTeam9.Models.ViewModel;

namespace CaseStudyTeam9.Models
{
    public interface IAccountRepo
    {
        List<int> getCustomerIDs();
        Account GetAccountByID(int id);
        int AddAccount(Account account);
        List<Account> GetAllAccount(int skipAccounts);
        bool DeleteAccount(int accountID);
        AccountViewModel SearchAccount(int id);
        List<AccountViewModel> SearchCustAcct(int id);
        List<AccountViewModel> SearchCustSSN(int id);
    }
}
