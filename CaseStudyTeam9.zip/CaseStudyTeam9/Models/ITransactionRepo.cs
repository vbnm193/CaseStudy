﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using CaseStudyTeam9.Models.ViewModel;

namespace CaseStudyTeam9.Models
{
    public interface ITransactionRepo
    {
        Transactions DepositMoney(int AccountID, decimal transactionAmount);
        Transactions WithdrawMoney(int AccountID, decimal transactionAmount);
        Transactions TransferMoney(int AccountID, int ToAccountID, decimal transactionAmount);
        List<TransactionsViewModel> TranReport(int acctID, int RowNum);
    }
}
