﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace CaseStudyTeam9.Models
{
    public class Account
    {
        [Key]
        [Display(Name = "Account ID")]
        public int AccountID { get; set; }
        [Required, Display(Name = "Customer ID")]
        public int CustomerID { get; set; }
        [Required, Display(Name = "Account Type")]
        public string AccountType { get; set; }

        [Required, Range(0, Int32.MaxValue)]
        public decimal Balance { get; set; }

        public string Status { get; set; } = "Active";
        public string Message { get; set; }
        [Display(Name = "Last Updated")]
        public DateTime LastUpdated { get; set; }
        public int SSN { get; set; }
    }
}
