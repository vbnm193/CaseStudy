﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CaseStudyTeam9.Models.ViewModel;

namespace CaseStudyTeam9.Models
{
    public class AccountRepo : IAccountRepo
    {
        AccountContext _context;
        public AccountRepo(AccountContext context)
        {
            _context = context;
        }
        public AccountViewModel SearchAccount(int AccountID)        
        {
            var res = _context.Account
                .Join(
            _context.Customer,
            a => a.CustomerID,
            b => b.CustomerID, (a, ab) => new AccountViewModel
            {
                AccountID = a.AccountID,
                CustomerID = a.CustomerID,
                AccountType = a.AccountType,
                Balance = a.Balance,
                SSN = a.SSN,
                Name = ab.Name
            }).FirstOrDefault(a => a.AccountID == AccountID);
            return res;
        }
        public List<AccountViewModel> SearchCustAcct(int id)
        {
            var res = _context.Account
                 .Where(a => a.CustomerID == id)
                 .Join(
                _context.Customer,
                a => a.CustomerID,
                b => b.CustomerID, (a, ab) => new AccountViewModel
                {
                    AccountID = a.AccountID,
                    CustomerID = a.CustomerID,
                    AccountType = a.AccountType,
                    Balance = a.Balance,
                    SSN = a.SSN,
                    Name = ab.Name
                });
            return res.ToList();
        }
        public List<AccountViewModel> SearchCustSSN(int SSNid)
        {
            var res = _context.Account
                 .Where(a => a.SSN == SSNid)
                 .Join(
                _context.Customer,
                a => a.CustomerID,
                b => b.CustomerID, (a, ab) => new AccountViewModel
                {
                    AccountID = a.AccountID,
                    CustomerID = a.CustomerID,
                    AccountType = a.AccountType,
                    Balance = a.Balance,
                    SSN = a.SSN,
                    Name = ab.Name
                });
            return res.ToList();
        }

        public int AddAccount(Account account)
        {
            if (_context.Account.Where(c => c.AccountType.Equals(account.AccountType) && c.CustomerID == account.CustomerID).Count() > 0)
            {
                return 0;
            }
            var customer = _context.Customer.Where(c => c.CustomerID == account.CustomerID).FirstOrDefault();
            account.SSN = customer.SSN;
            account.LastUpdated = DateTime.Now;
            _context.Account.Add(account);
            return _context.SaveChanges();
        }

        public List<int> getCustomerIDs()
        {
            return _context.Customer.Select(c => c.CustomerID).ToList();
        }

        public List<Account> GetAllAccount(int skipAccounts)
        {
            int accountPerPage = 5;
            return _context.Account.Skip(skipAccounts* accountPerPage).Take(accountPerPage).ToList();
        }

        public bool DeleteAccount(int accountID)
        {
            var account = _context.Account.Where(a => a.AccountID == accountID).FirstOrDefault();
            _context.Account.Remove(account);
            _context.SaveChanges();
            return true;
        }
        public Account GetAccountByID(int id)
        {
            return _context.Account.FirstOrDefault(a => a.AccountID == id);
        }
    }
}
