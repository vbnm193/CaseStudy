﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaseStudyTeam9.Models
{
    public class AccountContext : DbContext
    {
        public AccountContext(DbContextOptions<AccountContext> option) : base(option) { }       
        public DbSet<Account> Account { get; set; }
        public DbSet<Customer> Customer { get; set; }
    }
}
