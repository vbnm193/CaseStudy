﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace CaseStudyTeam9.Models
{
    public class Transactions
    {
        [Key]
        [Display(Name = "Transaction ID")]
        public int TransactionID { get; set; }
        [Display(Name = "To Account ID")]
        public int ToAccountID { get; set; }
        [Display(Name = "Account ID")]
        public int AccountID { get; set; }
        [Display(Name = "Customer ID")]
        public int CustomerID { get; set; }
        [Display(Name = "Account Type")]
        public string AccountType { get; set; }

        [Range(1, Int32.MaxValue)]
        [Display(Name = "Transaction Amount")]
        public decimal TransactionAmount { get; set; }
        [Display(Name = "Current Balance")]
        public decimal CurrentBalance { get; set; }
        [Display(Name = "Closing Balance")]
        public decimal ClosingBalance { get; set; }
        [Display(Name = "Transaction Date")]
        public DateTime TransactionDate { get; set; }

    }
}
