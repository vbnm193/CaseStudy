﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using CaseStudyTeam9.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Authorization;

namespace CaseStudyTeam9.Controllers
{
    [Authorize(Roles = "Customer Executive")]
    public class CustomerController : Controller
    {
        private ICustomerRepo _repo;
        public CustomerController(ICustomerRepo repo)
        {
            _repo = repo;
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult CreateCustomer()
        {
            List<string> stateList = StateList();

            ViewBag.States = stateList;
            return View();
        }
        public List<string> StateList()
        {
            List<string> items = new List<string>
            {
                new string("AL"),
                new string("AK"),
                new string("AZ"),
                new string("AR"),
                new string("CA"),
                new string("CO"),
                new string("CT"),
                new string("DE"),
                new string("FL"),
                new string("GA"),
                new string("HI"),
                new string("ID"),
                new string("IL"),
                new string("IN"),
                new string("IA"),
                new string("KS"),
                new string("KY"),
                new string("LA"),
                new string("ME"),
                new string("MD"),
                new string("MA"),
                new string("MI"),
                new string("MN"),
                new string("MS"),
                new string("MO"),
                new string("MT"),
                new string("NE"),
                new string("NV"),
                new string("NH"),
                new string("NJ"),
                new string("NM"),
                new string("NY"),
                new string("NC"),
                new string("ND"),
                new string("OH"),
                new string("OK"),
                new string("OR"),
                new string("PA"),
                new string("RI"),
                new string("SC"),
                new string("SD"),
                new string("TN"),
                new string("TX"),
                new string("UT"),
                new string("VT"),
                new string("VA"),
                new string("WA"),
                new string("WV"),
                new string("WI"),
                new string("WY")
            };
            return items;
        }
        [HttpPost]
        public IActionResult CreateCustomer(Customer customer)
        {
            if (!ModelState.IsValid)
            {
                List<string> stateList = StateList();

                ViewBag.States = stateList;
                return View();
            }
            else
            {
                try
                {
                    List<string> stateList = StateList();

                    ViewBag.States = stateList;
                    ViewBag.SSN = customer.SSN;
                    int changes = _repo.AddCustomer(customer);
                    if (changes > 0)
                    {
                        ViewBag.Message = "1";
                        return View(customer);
                    }
                    else
                    {
                        ViewBag.Message = "0";
                        return View(customer);
                    }                      
                }
                catch
                {
                    ViewBag.Message = "0";
                    return View(customer);
                }
            }
        }
        [HttpGet]
        public IActionResult Error(int SSN)
        {
            ViewBag.SSN = SSN;
            return View();
        }
        [HttpGet]
        public IActionResult ViewAllCustomer(string msg, int page)
        {
            ViewBag.page = page;
            ViewBag.msg = msg;
            return View(_repo.GetAllCustomer(page));
        }
        

        [HttpGet]
        public IActionResult ErrorCustomerDelete()
        {
            return View();
        }

        [HttpGet]
        public IActionResult SuccessCustomerDelete()
        {
            return View();
        }
        public IActionResult DeleteCustomer(int customerID)
        {
            try
            {
                bool isDeleted = _repo.DeleteCustomer(customerID);
                if(isDeleted)
                {
                    return RedirectToAction("SuccessCustomerDelete");
                }
                string msg = $"Cutomer {customerID} has one or more accounts. Customer can not be deleted";
                return RedirectToAction("ViewAllCustomer", new { msg = msg });
            }
            catch
            {
                return RedirectToAction("ErrorCustomerDelete");
            }
        }
        public IActionResult EditCustomer(int customerID)
        {
            List<string> stateList = StateList();

            ViewBag.States = stateList;
            return View(_repo.GetCustomerByID(customerID));
        }
        [HttpPost]
        public IActionResult EditCustomer(Customer customer)
        {
            List<string> stateList = StateList();

            ViewBag.States = stateList;
            if (ModelState.IsValid)
            {
                ViewBag.CustomerID = customer.CustomerID;
                ViewBag.SSN = customer.SSN;
                int edit = _repo.UpdateCustomer(customer);
                if(edit > 0)
                {
                    ViewBag.Message = "1";
                }
                else
                {
                    ViewBag.Message = "0";
                }
                return View(customer);
            }
            return View(_repo.GetCustomerByID(customer.CustomerID));
        }
        public IActionResult Details(int customerID)
        {
            return View(_repo.GetCustomerByID(customerID));
        }
        public IActionResult EditSuccess(int customerID, int ssn)
        {
            ViewBag.CustomerID = customerID;
            ViewBag.SSN = ssn;
            return View();
        }
        [AllowAnonymous]
        public IActionResult SearchCustomer()
        {
            return View();
        }
        [AllowAnonymous]
        [HttpPost]
        public IActionResult SearchCustomer(string searchBy, int id)
        {
            if (ModelState.IsValid)
            {
                return View(_repo.SearchCustomer(searchBy, id));
            }
            else return View();
        }
        public IActionResult ViewAllCustomer(int page)
        {
            ViewBag.page = page;
            return View(_repo.GetAllCustomer(page));
        }
    }
}
