﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using CaseStudyTeam9.Models;
using CaseStudyTeam9.Models.ViewModel;
using Microsoft.AspNetCore.Authorization;

namespace CaseStudyTeam9.Controllers
{
    [Authorize(Roles = "Cashier,Teller")]
    public class TransactionController : Controller
    {
        ITransactionRepo transactionRepo;
        IAccountRepo actRepo;
        public TransactionController(ITransactionRepo tRepo, IAccountRepo aRepo)
        {
            transactionRepo = tRepo;
            actRepo = aRepo;
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Deposit()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Deposit(decimal transactionAmount, int AccountID)
        {
            if (ModelState.IsValid)
            {
                Transactions t = transactionRepo.DepositMoney(AccountID, transactionAmount);
                if(t == null)
                {
                    ViewBag.Message = "1";
                }
                else ViewBag.Message = "0";
                return View(t);            
            }
            else
                return View();
        }
        public IActionResult Withdraw()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Withdraw(decimal transactionAmount, int AccountID)
        {
            if (ModelState.IsValid)
            {
                Transactions t = transactionRepo.WithdrawMoney(AccountID, transactionAmount);
                if (t == null)
                {
                    ViewBag.Message = "1";
                }
                else if(t.TransactionAmount == -1)
                {
                    ViewBag.Message = "2";
                }
                else ViewBag.Message = "0";
                return View(t);
            }
            else
                return View();
        }
        public IActionResult Transfer()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Transfer(int AccountID, int ToAccountId, decimal transactionAmount)
        {
            if (ModelState.IsValid)
            {
                Transactions t = transactionRepo.TransferMoney(AccountID, ToAccountId, transactionAmount);
                if (t == null)
                {
                    ViewBag.Message = "1";
                }
                else if (t.TransactionAmount == -1)
                {
                    ViewBag.Message = "2";
                }
                else ViewBag.Message = "0";
                return View(t);
            }
            else
                return View();
        }
        public IActionResult Report()
        {
            TransactionsCreateViewModel transactionsCreateViewModel = new TransactionsCreateViewModel { };
            return View(transactionsCreateViewModel);
        }

        [HttpPost]
        public IActionResult Report(int acctID, int RowNum)
        {
            TransactionsCreateViewModel transactionsCreateViewModel = new TransactionsCreateViewModel
            {
                transactionsViewModels = transactionRepo.TranReport(acctID,RowNum)
            };
            if(ModelState.IsValid)
            {
                if(transactionsCreateViewModel.transactionsViewModels.Count == 0)
                {
                    ViewBag.Message = "0";
                    return View(transactionsCreateViewModel);
                }
                else
                {
                    ViewBag.Message = "1";
                }
            }
            return View(transactionsCreateViewModel);
        }
    }
}

