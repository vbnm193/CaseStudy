﻿using System; 
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using CaseStudyTeam9.Models;
using CaseStudyTeam9.Models.ViewModel;
using Microsoft.AspNetCore.Authorization;

namespace CaseStudyTeam9.Controllers
{
    [Authorize(Roles = "Account Executive")]
    public class AccountController : Controller
    {
        IAccountRepo actRepo;
        ICustomerRepo custRepo;
        public AccountController(IAccountRepo aRepo, ICustomerRepo cRepo)
        {
            actRepo = aRepo;
            custRepo = cRepo;
        }
        // Search For Bank Account
        public IActionResult Index()
        {
            return View();
        }
        [AllowAnonymous]
        public IActionResult Search()
        {
            AccountCreateViewModel accountCreateViewModel = new AccountCreateViewModel { };
            return View(accountCreateViewModel);
        }
        [AllowAnonymous]
        [HttpPost]
        public IActionResult Search(int id, string search, int acctID)
        {
            if (search == "CustomerID")
            {
                AccountCreateViewModel accountCreateViewModel = new AccountCreateViewModel
                {
                    AccountViewModels = actRepo.SearchCustAcct(id)
                };
                if (ModelState.IsValid)
                {
                    return View(accountCreateViewModel);
                }
                else return View(accountCreateViewModel);
            }
            else if (search == "SSN")
            {
                AccountCreateViewModel accountCreateViewModel = new AccountCreateViewModel
                {
                    AccountViewModels = actRepo.SearchCustSSN(id)
                };
                if (ModelState.IsValid)
                {
                    return View(accountCreateViewModel);
                }
                else return View(accountCreateViewModel);
            }
            else
            {
                AccountCreateViewModel accountCreateViewModel = new AccountCreateViewModel
                {
                    AccountViewModelC = actRepo.SearchAccount(id),
                    AccountViewModelA = actRepo.SearchAccount(acctID)
                };
                if (ModelState.IsValid)
                {
                    return View(accountCreateViewModel);
                }
                else return View("Search");
            }
        }

        [HttpGet]
        public IActionResult Error(int customerID)
        {
            ViewBag.customerID = customerID;
            return View();
        }

        public IActionResult CreateAccount()
        {
            List<int> CustomerIDs = actRepo.getCustomerIDs();
            ViewBag.CustomerIDs = CustomerIDs;
            ViewBag.AccountTypes = new List<string>{ "Saving", "Checking"};
            ViewBag.StatusType = new List<string> { "Active", "Inactive" };
            return View();
        }
        [HttpPost]
        public IActionResult CreateAccount(Account account)
        {
            if (!ModelState.IsValid)
            {
                return View();
            }
            else
            {
                try
                {
                    
                    int changes = actRepo.AddAccount(account);
                    if (changes > 0)
                        return RedirectToAction("ViewAllAccount");
                    else
                        return RedirectToAction("Error", new { customerID = account.CustomerID });
                }
                catch
                {
                    return RedirectToAction("Error", new { customerID = account.CustomerID });
                }
            }
        }

        public IActionResult ViewAllAccount(int page)
        {
            ViewBag.page = page;
            return View(actRepo.GetAllAccount(page));
        }

        [HttpGet]
        public IActionResult ErrorAccountDelete(int accountID)
        {
            ViewBag.accountID = accountID;
            return View();
        }

        [HttpGet]
        public IActionResult SuccessAccountDelete()
        {
            return View();
        }
        public IActionResult DeleteAccount(int accountID, decimal balance)
        {
            if (balance != 0)
            {
                return RedirectToAction("ErrorAccountDelete", new { accountID = accountID });
            }
            try
            {
                bool isDeleted = actRepo.DeleteAccount(accountID);
                if (isDeleted)
                {
                    return RedirectToAction("SuccessAccountDelete");
                }
                return RedirectToAction("ErrorAccountDelete", new { accountID = accountID });
            }
            catch
            {
                return RedirectToAction("ErrorAccountDelete", new { accountID = accountID });
            }
        }
    }
}
